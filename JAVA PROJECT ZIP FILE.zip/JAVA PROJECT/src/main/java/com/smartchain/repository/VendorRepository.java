package com.smartchain.repository;

import com.smartchain.model.Vendor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data JPA Repository for the Vendor entity.
 * Provides ready-to-use CRUD operations:
 * - save(vendor)
 * - findAll()
 * - findById(id)
 * - deleteById(id)
 */
@Repository
public interface VendorRepository extends JpaRepository<Vendor, Long> {

    // Derived query to find vendors by product name (case-insensitive)
    List<Vendor> findByProductIgnoreCase(String product);
}
