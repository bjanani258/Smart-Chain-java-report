package com.smartchain;

import com.smartchain.dao.VendorDAO;
import com.smartchain.dto.SearchRequest;
import com.smartchain.model.Vendor;
import com.smartchain.service.VendorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

/**
 * Unit Tests for VendorService verifying all 6 Test Cases required by the project specification,
 * tested with the JDBC Data Access Object (VendorDAO).
 */
public class VendorServiceTest {

    private VendorDAO vendorDAO;
    private VendorService vendorService;

    @BeforeEach
    void setUp() {
        vendorDAO = Mockito.mock(VendorDAO.class);
        vendorService = new VendorService(vendorDAO);
    }

    @Test
    @DisplayName("Test Case 1: Rice 50kg in Kundrathur matches Customer Rice 20kg in Kundrathur")
    void testCase1_ExactProductSufficientQuantityMatchingArea_ShouldMatch() {
        Vendor v1 = new Vendor("Kumar Stores", "9876543210", "12, Gandhi Road, Kundrathur, Chennai", "Rice", 50);
        when(vendorDAO.getAllVendors()).thenReturn(List.of(v1));

        SearchRequest req = new SearchRequest("Rice", 20, "Kundrathur");
        List<Vendor> matches = vendorService.searchMatchingVendors(req);

        assertEquals(1, matches.size());
        assertEquals("Kumar Stores", matches.get(0).getVendorName());
    }

    @Test
    @DisplayName("Test Case 2: Rice 10kg in Kundrathur fails Customer Rice 20kg (Insufficient Quantity)")
    void testCase2_InsufficientQuantity_ShouldNotMatch() {
        Vendor v2 = new Vendor("Ravi Traders", "9876501234", "25, Main Road, Kundrathur, Chennai", "Rice", 10);
        when(vendorDAO.getAllVendors()).thenReturn(List.of(v2));

        SearchRequest req = new SearchRequest("Rice", 20, "Kundrathur");
        List<Vendor> matches = vendorService.searchMatchingVendors(req);

        assertTrue(matches.isEmpty(), "Should not match because available quantity (10) < required quantity (20)");
    }

    @Test
    @DisplayName("Test Case 3: Wheat 50kg fails Customer Rice 20kg (Product Mismatch)")
    void testCase3_ProductMismatch_ShouldNotMatch() {
        Vendor v3 = new Vendor("ABC Store", "9876512345", "8, Kundrathur Main Road, Chennai", "Wheat", 50);
        when(vendorDAO.getAllVendors()).thenReturn(List.of(v3));

        SearchRequest req = new SearchRequest("Rice", 20, "Kundrathur");
        List<Vendor> matches = vendorService.searchMatchingVendors(req);

        assertTrue(matches.isEmpty(), "Should not match because Wheat != Rice");
    }

    @Test
    @DisplayName("Test Case 4: Porur address fails Customer Kundrathur search (Address Mismatch)")
    void testCase4_AddressMismatch_ShouldNotMatch() {
        Vendor v4 = new Vendor("Sri Shop", "9876523456", "20, Main Road, Porur, Chennai", "Rice", 50);
        when(vendorDAO.getAllVendors()).thenReturn(List.of(v4));

        SearchRequest req = new SearchRequest("Rice", 20, "Kundrathur");
        List<Vendor> matches = vendorService.searchMatchingVendors(req);

        assertTrue(matches.isEmpty(), "Should not match because 'Kundrathur' is not inside '20, Main Road, Porur, Chennai'");
    }

    @Test
    @DisplayName("Test Case 5: Case-insensitive matching (rice, kundrathur vs Rice, Kundrathur)")
    void testCase5_CaseInsensitiveMatching_ShouldMatch() {
        Vendor v5 = new Vendor("Kumar Stores", "9876543210", "Kundrathur, Chennai", "Rice", 20);
        when(vendorDAO.getAllVendors()).thenReturn(List.of(v5));

        SearchRequest req = new SearchRequest("rice", 20, "kundrathur");
        List<Vendor> matches = vendorService.searchMatchingVendors(req);

        assertEquals(1, matches.size());
        assertEquals("Kumar Stores", matches.get(0).getVendorName());
    }

    @Test
    @DisplayName("Test Case 6: Substring address matching with keyword")
    void testCase6_SubstringAddressMatching_ShouldMatch() {
        Vendor v6 = new Vendor("Kumar Stores", "9876543210", "12, Gandhi Road, Kundrathur, Chennai", "Rice", 100);
        when(vendorDAO.getAllVendors()).thenReturn(List.of(v6));

        SearchRequest req = new SearchRequest("Rice", 20, "Kundrathur");
        List<Vendor> matches = vendorService.searchMatchingVendors(req);

        assertEquals(1, matches.size());
        assertEquals("Kumar Stores", matches.get(0).getVendorName());
    }

    @Test
    @DisplayName("Multiple Matching Vendors: Both Kumar Stores and Sri Traders should be returned")
    void testMultipleMatchingVendors_BothShouldBeReturned() {
        Vendor v1 = new Vendor("Kumar Stores", "9876543210", "12, Gandhi Road, Kundrathur, Chennai", "Rice", 50);
        Vendor v2 = new Vendor("Sri Traders", "9876523456", "100, Bazaar Street, Kundrathur, Chennai", "Rice", 100);
        when(vendorDAO.getAllVendors()).thenReturn(List.of(v1, v2));

        SearchRequest req = new SearchRequest("Rice", 20, "Kundrathur");
        List<Vendor> matches = vendorService.searchMatchingVendors(req);

        assertEquals(2, matches.size());
        assertEquals("Kumar Stores", matches.get(0).getVendorName());
        assertEquals("Sri Traders", matches.get(1).getVendorName());
    }
}
