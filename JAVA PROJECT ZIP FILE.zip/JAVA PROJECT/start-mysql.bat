@echo off
title SMART CHAIN - MySQL Server
echo ===================================================
echo   Starting SMART CHAIN MySQL Server on Port 3307
echo ===================================================
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqld.exe" --datadir="%~dp0mysql-db" --port=3307 --console
pause
