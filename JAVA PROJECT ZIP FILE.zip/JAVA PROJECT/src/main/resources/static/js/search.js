// Customer Search JavaScript

document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('search-form');
    const productInput = document.getElementById('searchProduct');
    const quantityInput = document.getElementById('searchQuantity');
    const areaInput = document.getElementById('searchArea');
    const notificationArea = document.getElementById('notification-area');
    const resultsOutput = document.getElementById('results-output');
    const resultsCountBadge = document.getElementById('results-count-badge');
    const chipButtons = document.querySelectorAll('.btn-chip');

    // Handle Quick Demo Test Buttons (1-click loading)
    chipButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            productInput.value = btn.getAttribute('data-product');
            quantityInput.value = btn.getAttribute('data-qty');
            areaInput.value = btn.getAttribute('data-area');
            
            // Highlight button briefly
            btn.style.borderColor = '#38bdf8';
            setTimeout(() => {
                btn.style.borderColor = '';
            }, 600);

            // Automatically trigger the search
            performSearch();
        });
    });

    // Handle Search Form Submission
    searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        performSearch();
    });

    async function performSearch() {
        const product = productInput.value.trim();
        const quantity = parseInt(quantityInput.value, 10);
        const area = areaInput.value.trim();

        // Validation: Ensure all 3 required fields are entered
        if (!product) {
            showNotification('Please enter a product name.', 'error');
            productInput.focus();
            return;
        }

        if (isNaN(quantity) || quantity <= 0) {
            showNotification('Required quantity must be greater than 0.', 'error');
            quantityInput.focus();
            return;
        }

        if (!area) {
            showNotification('Please enter an address or area keyword.', 'error');
            areaInput.focus();
            return;
        }

        // Show loading state
        resultsOutput.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">⏳</div>
                <div class="empty-state-text">Searching Database...</div>
                <div class="empty-state-sub">Evaluating Product, Quantity, and Area conditions...</div>
            </div>
        `;

        try {
            const response = await fetch('/api/search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    product: product,
                    quantity: quantity,
                    area: area
                })
            });

            const data = await response.json();

            if (!response.ok) {
                showNotification(data.message || 'Error occurred while searching.', 'error');
                resultsOutput.innerHTML = `
                    <div class="alert alert-error">
                        ${escapeHtml(data.message || 'Error searching database.')}
                    </div>
                `;
                return;
            }

            renderResults(data.vendors, product, quantity, area);

        } catch (error) {
            console.error('Search request error:', error);
            showNotification('Server communication error. Make sure Spring Boot backend is running.', 'error');
            resultsOutput.innerHTML = `
                <div class="alert alert-error">
                    Could not connect to backend server. Make sure it is running on http://localhost:8080.
                </div>
            `;
        }
    }

    function renderResults(vendors, queryProduct, queryQty, queryArea) {
        if (!vendors || vendors.length === 0) {
            // Exact requirement from prompt: "No matching vendors found."
            resultsCountBadge.style.display = 'none';
            resultsOutput.innerHTML = `
                <div class="empty-state" style="border-color: rgba(239, 68, 68, 0.3);">
                    <div class="empty-state-icon">❌</div>
                    <div class="empty-state-text" style="color: #f87171;">No matching vendors found.</div>
                    <div class="empty-state-sub">
                        No vendor satisfied all 3 conditions: Product="${escapeHtml(queryProduct)}", Available Qty >= ${queryQty}, Area contains "${escapeHtml(queryArea)}".
                    </div>
                </div>
            `;
            return;
        }

        // Show count badge
        resultsCountBadge.textContent = `${vendors.length} Matched`;
        resultsCountBadge.style.display = 'inline-block';

        // Render matched vendors
        let html = `<div class="matched-grid">`;
        vendors.forEach((v, index) => {
            html += `
                <div class="vendor-result-card">
                    <div class="v-card-header">
                        <div>
                            <div style="font-size: 0.75rem; color: #38bdf8; font-weight: 700; margin-bottom: 2px;">
                                MATCH #${index + 1}
                            </div>
                            <h4 class="v-card-name">${escapeHtml(v.vendorName)}</h4>
                        </div>
                        <span class="v-card-status">✓ MATCHED</span>
                    </div>

                    <div class="v-detail-row">
                        <span class="v-detail-label">📞 Phone:</span>
                        <span class="v-detail-value">
                            <a href="tel:${escapeHtml(v.phoneNumber)}" style="color: #38bdf8; text-decoration: underline; font-weight: 700;" title="Click to call ${escapeHtml(v.vendorName)}">
                                ${escapeHtml(v.phoneNumber)}
                            </a>
                        </span>
                    </div>

                    <div class="v-detail-row">
                        <span class="v-detail-label">📍 Address:</span>
                        <span class="v-detail-value">${highlightKeyword(v.shopAddress, queryArea)}</span>
                    </div>

                    <div class="v-detail-row">
                        <span class="v-detail-label">📦 Product:</span>
                        <span class="v-detail-value">
                            <span class="v-badge-pill badge-product">${escapeHtml(v.product)}</span>
                        </span>
                    </div>

                    <div class="v-detail-row">
                        <span class="v-detail-label">📊 Stock:</span>
                        <span class="v-detail-value">
                            <span class="v-badge-pill badge-qty">${v.availableQuantity} units available (>= ${queryQty})</span>
                        </span>
                    </div>
                </div>
            `;
        });
        html += `</div>`;

        resultsOutput.innerHTML = html;
        resultsOutput.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    // Helper to highlight the matching address keyword
    function highlightKeyword(address, keyword) {
        if (!address || !keyword) return escapeHtml(address);
        const regex = new RegExp(`(${escapeRegex(keyword)})`, 'gi');
        return escapeHtml(address).replace(regex, '<mark style="background: rgba(56, 189, 248, 0.35); color: #fff; padding: 1px 4px; border-radius: 3px;">$1</mark>');
    }

    function escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function showNotification(message, type = 'info') {
        const alertClass = type === 'error' ? 'alert-error' : (type === 'success' ? 'alert-success' : 'alert-info');
        const icon = type === 'error' ? '⚠️' : 'ℹ️';

        notificationArea.innerHTML = `
            <div class="alert ${alertClass}">
                <span>${icon}</span>
                <span>${escapeHtml(message)}</span>
            </div>
        `;

        setTimeout(() => {
            if (notificationArea.firstElementChild) {
                notificationArea.innerHTML = '';
            }
        }, 5000);
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
});
