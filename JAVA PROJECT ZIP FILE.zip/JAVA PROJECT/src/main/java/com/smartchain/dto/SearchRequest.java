package com.smartchain.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Data Transfer Object (DTO) capturing search criteria submitted by the customer.
 * 
 * Contains ONLY the 3 required fields:
 * 1. product (e.g. "Rice")
 * 2. quantity (e.g. 20)
 * 3. area (e.g. "Kundrathur") - keyword/substring of address
 */
public class SearchRequest {

    @NotBlank(message = "Product name cannot be empty")
    private String product;

    @NotNull(message = "Required quantity is mandatory")
    @Min(value = 1, message = "Required quantity must be greater than 0")
    private Integer quantity;

    @NotBlank(message = "Address or area keyword cannot be empty")
    private String area;

    public SearchRequest() {
    }

    public SearchRequest(String product, Integer quantity, String area) {
        this.product = product;
        this.quantity = quantity;
        this.area = area;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "SearchRequest{" +
                "product='" + product + '\'' +
                ", quantity=" + quantity +
                ", area='" + area + '\'' +
                '}';
    }
}
