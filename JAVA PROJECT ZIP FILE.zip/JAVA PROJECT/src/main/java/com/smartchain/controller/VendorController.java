package com.smartchain.controller;

import com.smartchain.model.Vendor;
import com.smartchain.service.VendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Vendor operations.
 * Handles adding vendors, retrieving vendor lists, and loading demo data.
 */
@RestController
@RequestMapping("/api/vendors")
@CrossOrigin(origins = "*")
public class VendorController {

    private final VendorService vendorService;

    @Autowired
    public VendorController(VendorService vendorService) {
        this.vendorService = vendorService;
    }

    /**
     * Endpoint to add a new vendor.
     * Validates input fields and saves vendor to MySQL.
     */
    @PostMapping
    public ResponseEntity<?> addVendor(@RequestBody Vendor vendor) {
        // Validation: Empty check
        if (vendor.getVendorName() == null || vendor.getVendorName().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Vendor name cannot be empty"));
        }
        if (vendor.getPhoneNumber() == null || vendor.getPhoneNumber().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Phone number cannot be empty"));
        }
        if (vendor.getShopAddress() == null || vendor.getShopAddress().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Shop address cannot be empty"));
        }
        if (vendor.getProduct() == null || vendor.getProduct().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Product cannot be empty"));
        }
        if (vendor.getAvailableQuantity() == null || vendor.getAvailableQuantity() <= 0) {
            return ResponseEntity.badRequest().body(Map.of("message", "Available quantity must be greater than 0"));
        }

        Vendor savedVendor = vendorService.addVendor(vendor);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Vendor details added successfully.");
        response.put("vendor", savedVendor);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    /**
     * Endpoint to retrieve all registered vendors.
     */
    @GetMapping
    public ResponseEntity<List<Vendor>> getAllVendors() {
        return ResponseEntity.ok(vendorService.getAllVendors());
    }

    /**
     * Helper endpoint for college project evaluation.
     * Inserts the 4 standard demo vendors (Kumar Stores, Ravi Traders, ABC Store, Sri Shop).
     */
    @PostMapping("/sample-data")
    public ResponseEntity<?> loadSampleData() {
        List<Vendor> demoVendors = vendorService.loadDemoVendors();
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Demo vendors loaded successfully into database.");
        response.put("count", demoVendors.size());
        response.put("vendors", demoVendors);
        return ResponseEntity.ok(response);
    }
}
