-- ===================================================
-- SMART CHAIN DATABASE SCHEMA
-- ===================================================

CREATE DATABASE IF NOT EXISTS smartchain;
USE smartchain;

CREATE TABLE IF NOT EXISTS vendor (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    vendor_name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50) NOT NULL,
    shop_address VARCHAR(500) NOT NULL,
    product VARCHAR(255) NOT NULL,
    available_quantity INT NOT NULL
);

-- Sample Data (Test Cases)
-- INSERT INTO vendor (vendor_name, phone_number, shop_address, product, available_quantity) VALUES
-- ('Kumar Stores', '9876543210', '12, Gandhi Road, Kundrathur, Chennai', 'Rice', 50),
-- ('Ravi Traders', '9876501234', '25, Main Road, Kundrathur, Chennai', 'Rice', 15),
-- ('ABC Store', '9876512345', '8, Kundrathur Main Road, Chennai', 'Wheat', 100),
-- ('Sri Shop', '9876523456', '20, Main Road, Porur, Chennai', 'Rice', 100);
