package com.smartchain.controller;

import com.smartchain.dto.SearchRequest;
import com.smartchain.model.Vendor;
import com.smartchain.service.VendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Customer Search requests.
 * Receives the 3 customer inputs (product, quantity, area)
 * and returns vendors satisfying all 3 conditions.
 */
@RestController
@RequestMapping("/api/search")
@CrossOrigin(origins = "*")
public class SearchController {

    private final VendorService vendorService;

    @Autowired
    public SearchController(VendorService vendorService) {
        this.vendorService = vendorService;
    }

    /**
     * Search endpoint handling POST requests with JSON payload.
     */
    @PostMapping
    public ResponseEntity<?> searchVendors(@RequestBody SearchRequest request) {
        // Validation: Ensure all 3 customer inputs are present and valid
        if (request.getProduct() == null || request.getProduct().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Product cannot be empty"));
        }
        if (request.getQuantity() == null || request.getQuantity() <= 0) {
            return ResponseEntity.badRequest().body(Map.of("message", "Required quantity must be greater than 0"));
        }
        if (request.getArea() == null || request.getArea().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Address or Area cannot be empty"));
        }

        // Execute 3-condition matching algorithm in VendorService
        List<Vendor> matchedVendors = vendorService.searchMatchingVendors(request);

        Map<String, Object> response = new HashMap<>();
        response.put("matchedCount", matchedVendors.size());
        response.put("vendors", matchedVendors);

        if (matchedVendors.isEmpty()) {
            response.put("message", "No matching vendors found.");
        } else {
            response.put("message", "Found " + matchedVendors.size() + " matching vendor(s).");
        }

        return ResponseEntity.ok(response);
    }

    /**
     * Search endpoint handling GET requests with query parameters.
     * Example: /api/search?product=Rice&quantity=20&area=Kundrathur
     */
    @GetMapping
    public ResponseEntity<?> searchVendorsGet(
            @RequestParam(required = false) String product,
            @RequestParam(required = false) Integer quantity,
            @RequestParam(required = false) String area) {

        if (product == null || product.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Product cannot be empty"));
        }
        if (quantity == null || quantity <= 0) {
            return ResponseEntity.badRequest().body(Map.of("message", "Required quantity must be greater than 0"));
        }
        if (area == null || area.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Address or Area cannot be empty"));
        }

        SearchRequest request = new SearchRequest(product, quantity, area);
        List<Vendor> matchedVendors = vendorService.searchMatchingVendors(request);

        Map<String, Object> response = new HashMap<>();
        response.put("matchedCount", matchedVendors.size());
        response.put("vendors", matchedVendors);

        if (matchedVendors.isEmpty()) {
            response.put("message", "No matching vendors found.");
        } else {
            response.put("message", "Found " + matchedVendors.size() + " matching vendor(s).");
        }

        return ResponseEntity.ok(response);
    }
}
