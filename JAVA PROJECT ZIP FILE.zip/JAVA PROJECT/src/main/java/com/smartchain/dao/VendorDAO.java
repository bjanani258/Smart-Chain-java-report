package com.smartchain.dao;

import com.smartchain.model.Vendor;
import com.smartchain.util.DBConnection;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * =========================================================================
 * VendorDAO (Data Access Object) using Pure JDBC
 * =========================================================================
 * 
 * Demonstrates textbook JDBC programming concepts for 2nd-Year CSE:
 *   1. Connection establishment via DBConnection.getConnection()
 *   2. SQL queries executed with PreparedStatement (prevents SQL Injection)
 *   3. ResultSet iteration (rs.next(), rs.getString(), rs.getInt())
 *   4. Generated Key retrieval for AUTO_INCREMENT primary keys
 *   5. Resource management using Java try-with-resources
 */
@Repository
public class VendorDAO {

    /**
     * INSERT a new Vendor into MySQL using JDBC PreparedStatement.
     * 
     * @param vendor The Vendor object to insert
     * @return The saved Vendor object with its generated auto-increment ID
     */
    public Vendor saveVendor(Vendor vendor) {
        String sql = "INSERT INTO vendor (vendor_name, phone_number, shop_address, product, available_quantity) VALUES (?, ?, ?, ?, ?)";

        // Use try-with-resources to automatically close Connection and PreparedStatement
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Bind values to placeholders (?)
            pstmt.setString(1, vendor.getVendorName());
            pstmt.setString(2, vendor.getPhoneNumber());
            pstmt.setString(3, vendor.getShopAddress());
            pstmt.setString(4, vendor.getProduct());
            pstmt.setInt(5, vendor.getAvailableQuantity());

            // Execute the INSERT statement
            int affectedRows = pstmt.executeUpdate();
            System.out.println("[JDBC] Executed INSERT: " + affectedRows + " row(s) inserted.");

            // Retrieve generated primary key (id)
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    vendor.setId(generatedKeys.getLong(1));
                }
            }

            return vendor;

        } catch (SQLException e) {
            System.err.println("[JDBC ERROR] Error saving vendor: " + e.getMessage());
            throw new RuntimeException("Database error saving vendor via JDBC: " + e.getMessage(), e);
        }
    }

    /**
     * SELECT all Vendors from MySQL using JDBC PreparedStatement and ResultSet.
     * 
     * @return List of all Vendor objects found in the database
     */
    public List<Vendor> getAllVendors() {
        List<Vendor> vendors = new ArrayList<>();
        String sql = "SELECT id, vendor_name, phone_number, shop_address, product, available_quantity FROM vendor ORDER BY id ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            // Iterate over the ResultSet rows
            while (rs.next()) {
                Vendor vendor = new Vendor();
                vendor.setId(rs.getLong("id"));
                vendor.setVendorName(rs.getString("vendor_name"));
                vendor.setPhoneNumber(rs.getString("phone_number"));
                vendor.setShopAddress(rs.getString("shop_address"));
                vendor.setProduct(rs.getString("product"));
                vendor.setAvailableQuantity(rs.getInt("available_quantity"));

                vendors.add(vendor);
            }

            System.out.println("[JDBC] Executed SELECT: Retrieved " + vendors.size() + " vendor(s).");
            return vendors;

        } catch (SQLException e) {
            System.err.println("[JDBC ERROR] Error fetching vendors: " + e.getMessage());
            throw new RuntimeException("Database error fetching vendors via JDBC: " + e.getMessage(), e);
        }
    }

    /**
     * Save multiple vendors in batch (used for loading demo data).
     */
    public List<Vendor> saveAll(List<Vendor> vendors) {
        List<Vendor> savedList = new ArrayList<>();
        for (Vendor v : vendors) {
            savedList.add(saveVendor(v));
        }
        return savedList;
    }

    /**
     * Check if table exists or count total vendors.
     */
    public int countVendors() {
        String sql = "SELECT COUNT(*) FROM vendor";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        } catch (SQLException e) {
            System.err.println("[JDBC ERROR] Error counting vendors: " + e.getMessage());
            return 0;
        }
    }
}
