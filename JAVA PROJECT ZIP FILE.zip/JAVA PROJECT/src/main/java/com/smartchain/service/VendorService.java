package com.smartchain.service;

import com.smartchain.dao.VendorDAO;
import com.smartchain.dto.SearchRequest;
import com.smartchain.model.Vendor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Service Layer containing the Business Logic and the Core Matching Algorithm.
 * Data persistence is executed directly via JDBC (VendorDAO).
 * 
 * =========================================================================
 * MATCHING ALGORITHM EXPLANATION (For College Project Review):
 * =========================================================================
 * The customer enters 3 inputs:
 *   1. Product required (e.g., "Rice")
 *   2. Required quantity (e.g., 20)
 *   3. Area/Address keyword (e.g., "Kundrathur")
 * 
 * For every vendor retrieved from MySQL via JDBC, we check THREE conditions:
 *   Condition 1: Product Matching
 *     - vendor.product matches customer.product (case-insensitive, trimmed)
 * 
 *   Condition 2: Quantity Matching
 *     - vendor.availableQuantity >= customer.requiredQuantity
 *     - Note: Vendor can have MORE than or EQUAL to customer quantity.
 * 
 *   Condition 3: Address Substring Matching
 *     - customer's area keyword exists anywhere inside vendor's full shop address.
 *     - Checked using: vendorAddress.toLowerCase().contains(customerArea.toLowerCase())
 *     - Customer does NOT need to provide full address, only a keyword/area name.
 * 
 * If ALL THREE conditions evaluate to true, the vendor is added to the matched list.
 * If multiple vendors match, all matching vendors are returned.
 */
@Service
public class VendorService {

    // Direct JDBC Data Access Object
    private final VendorDAO vendorDAO;

    @Autowired
    public VendorService(VendorDAO vendorDAO) {
        this.vendorDAO = vendorDAO;
    }

    /**
     * Save a new vendor to the MySQL database using JDBC.
     */
    public Vendor addVendor(Vendor vendor) {
        if (vendor.getVendorName() != null) {
            vendor.setVendorName(vendor.getVendorName().trim());
        }
        if (vendor.getPhoneNumber() != null) {
            vendor.setPhoneNumber(vendor.getPhoneNumber().trim());
        }
        if (vendor.getShopAddress() != null) {
            vendor.setShopAddress(vendor.getShopAddress().trim());
        }
        if (vendor.getProduct() != null) {
            vendor.setProduct(vendor.getProduct().trim());
        }
        // Save using pure JDBC PreparedStatement
        return vendorDAO.saveVendor(vendor);
    }

    /**
     * Retrieve all registered vendors from the database using JDBC ResultSet.
     */
    public List<Vendor> getAllVendors() {
        return vendorDAO.getAllVendors();
    }

    /**
     * CORE MATCHING ALGORITHM
     * Filters vendors retrieved via JDBC from MySQL according to the 3 mandatory conditions.
     * 
     * @param request The customer's search criteria (product, quantity, area)
     * @return List of Vendors that strictly satisfy all three conditions
     */
    public List<Vendor> searchMatchingVendors(SearchRequest request) {
        List<Vendor> matchedVendors = new ArrayList<>();

        // Basic check for empty request
        if (request == null || request.getProduct() == null || request.getQuantity() == null || request.getArea() == null) {
            return matchedVendors;
        }

        // Step 1: Normalize customer inputs (trim spaces and convert to lowercase for comparison)
        String customerProduct = request.getProduct().trim();
        int customerQuantity = request.getQuantity();
        String customerAreaKeyword = request.getArea().trim().toLowerCase();

        // Step 2: Fetch all vendors currently in MySQL via JDBC
        List<Vendor> allVendors = vendorDAO.getAllVendors();

        // Step 3: Iterate through each vendor and test all 3 conditions
        for (Vendor vendor : allVendors) {
            if (vendor.getProduct() == null || vendor.getAvailableQuantity() == null || vendor.getShopAddress() == null) {
                continue;
            }

            // -------------------------------------------------------------
            // CONDITION 1: Product Match (Case-Insensitive)
            // Example: "rice" matches "Rice"
            // -------------------------------------------------------------
            boolean condition1Product = vendor.getProduct().trim().equalsIgnoreCase(customerProduct);

            // -------------------------------------------------------------
            // CONDITION 2: Quantity Match
            // Vendor's available quantity must be greater than or equal to customer's required quantity
            // Example: Vendor=50, Customer=20 -> TRUE (50 >= 20)
            //          Vendor=15, Customer=20 -> FALSE (15 < 20)
            // -------------------------------------------------------------
            boolean condition2Quantity = vendor.getAvailableQuantity() >= customerQuantity;

            // -------------------------------------------------------------
            // CONDITION 3: Address / Area Keyword Substring Match (Case-Insensitive)
            // Customer area keyword must appear somewhere inside vendor's full shop address
            // Example: Vendor="12, Gandhi Road, Kundrathur, Chennai"
            //          Customer keyword="kundrathur"
            //          vendorAddress.toLowerCase().contains("kundrathur") -> TRUE
            // -------------------------------------------------------------
            String vendorAddressNormalized = vendor.getShopAddress().toLowerCase();
            boolean condition3Address = vendorAddressNormalized.contains(customerAreaKeyword);

            // -------------------------------------------------------------
            // FINAL DECISION: Only if ALL THREE conditions are satisfied
            // -------------------------------------------------------------
            if (condition1Product && condition2Quantity && condition3Address) {
                matchedVendors.add(vendor);
            }
        }

        return matchedVendors;
    }

    /**
     * Helper method to populate college demonstration test cases via JDBC.
     */
    public List<Vendor> loadDemoVendors() {
        List<Vendor> sampleVendors = List.of(
            new Vendor("Kumar Stores", "9876543210", "12, Gandhi Road, Kundrathur, Chennai", "Rice", 50),
            new Vendor("Ravi Traders", "9876501234", "25, Main Road, Kundrathur, Chennai", "Rice", 15),
            new Vendor("ABC Store", "9876512345", "8, Kundrathur Main Road, Chennai", "Wheat", 100),
            new Vendor("Sri Shop", "9876523456", "20, Main Road, Porur, Chennai", "Rice", 100)
        );

        return vendorDAO.saveAll(sampleVendors);
    }
}
