package com.smartchain.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * =========================================================================
 * JDBC (Java Database Connectivity) Utility Class
 * =========================================================================
 * 
 * This class establishes a direct JDBC connection to the MySQL database.
 * 
 * Standard JDBC Steps for College Project Review:
 *   Step 1: Load and register the JDBC Driver (com.mysql.cj.jdbc.Driver)
 *   Step 2: Define connection credentials (URL, Username, Password)
 *   Step 3: Call DriverManager.getConnection() to open a database session
 */
public class DBConnection {

    // JDBC Driver Name for MySQL 8.0+
    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

    // JDBC Connection URL: connects to MySQL server on port 3307 for database 'smartchain'
    private static final String URL = "jdbc:mysql://localhost:3307/smartchain?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    // MySQL Database Credentials
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    // Static block to load the JDBC driver once when class is loaded
    static {
        try {
            Class.forName(JDBC_DRIVER);
            System.out.println("[JDBC] MySQL JDBC Driver registered successfully: " + JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("[JDBC ERROR] MySQL JDBC Driver not found: " + e.getMessage());
        }
    }

    /**
     * Factory method to obtain a new JDBC Connection.
     * 
     * @return java.sql.Connection active database connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    /**
     * Utility method to test if JDBC connection is working.
     */
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("[JDBC ERROR] Connection test failed: " + e.getMessage());
            return false;
        }
    }

    // Getters for configuration values (used for displaying in viva/status)
    public static String getUrl() {
        return URL;
    }

    public static String getUsername() {
        return USERNAME;
    }

    public static String getDriverName() {
        return JDBC_DRIVER;
    }
}
