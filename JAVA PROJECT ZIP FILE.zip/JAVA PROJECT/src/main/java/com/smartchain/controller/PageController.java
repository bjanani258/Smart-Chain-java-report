package com.smartchain.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller to map clean URL paths to static HTML views.
 */
@Controller
public class PageController {

    @GetMapping("/")
    public String home() {
        return "forward:/index.html";
    }

    @GetMapping("/vendor")
    public String vendorPage() {
        return "forward:/vendor.html";
    }

    @GetMapping("/search")
    public String searchPage() {
        return "forward:/search.html";
    }
}
