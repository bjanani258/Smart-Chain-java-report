package com.smartchain.controller;

import com.smartchain.dao.VendorDAO;
import com.smartchain.util.DBConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.util.HashMap;
import java.util.Map;

/**
 * Controller to provide live verification of the JDBC Connection status.
 * Useful for demonstrating direct JDBC connectivity during faculty review.
 */
@RestController
@RequestMapping("/api/jdbc")
@CrossOrigin(origins = "*")
public class JdbcStatusController {

    private final VendorDAO vendorDAO;

    @Autowired
    public JdbcStatusController(VendorDAO vendorDAO) {
        this.vendorDAO = vendorDAO;
    }

    /**
     * Endpoint: GET /api/jdbc/status
     * Returns live JDBC connection metadata from MySQL.
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getJdbcStatus() {
        Map<String, Object> response = new HashMap<>();

        try (Connection conn = DBConnection.getConnection()) {
            boolean isValid = conn != null && !conn.isClosed();
            DatabaseMetaData metaData = conn.getMetaData();

            response.put("status", "SUCCESS");
            response.put("jdbcConnected", isValid);
            response.put("driverName", metaData.getDriverName());
            response.put("driverVersion", metaData.getDriverVersion());
            response.put("databaseProductName", metaData.getDatabaseProductName());
            response.put("databaseProductVersion", metaData.getDatabaseProductVersion());
            response.put("connectionUrl", DBConnection.getUrl());
            response.put("totalVendorsInDB", vendorDAO.countVendors());
            response.put("message", "Direct JDBC Connection to MySQL 8.0 is ACTIVE and healthy!");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("status", "ERROR");
            response.put("jdbcConnected", false);
            response.put("error", e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }
}
