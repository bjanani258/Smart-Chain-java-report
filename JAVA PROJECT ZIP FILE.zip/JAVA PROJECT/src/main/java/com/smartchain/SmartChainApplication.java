package com.smartchain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot Application Entry Point for SMART CHAIN.
 * 
 * Project Name: SMART CHAIN
 * Description: Producer/Vendor and Customer Connectivity System
 */
@SpringBootApplication
public class SmartChainApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartChainApplication.class, args);
        System.out.println("=================================================");
        System.out.println("  SMART CHAIN Application Started Successfully!  ");
        System.out.println("  Open your browser at: http://localhost:8080    ");
        System.out.println("=================================================");
    }
}
