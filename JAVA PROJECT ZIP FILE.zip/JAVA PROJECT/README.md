# SMART CHAIN
### Producer/Vendor and Customer Connectivity System

A full-stack web application built with **Java 21**, **Spring Boot 3**, **Spring Data JPA**, **MySQL**, and modern **HTML5/CSS3/JavaScript**.

---

## 🚀 Quick Start (Running the Application)

### Step 1: Start MySQL Database
Double-click:
```cmd
start-mysql.bat
```
*(Or run in PowerShell / Command Prompt:)*
```powershell
& "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqld.exe" --datadir="mysql-db" --port=3307 --console
```
This runs the official MySQL Server instance on port **3307** with the `smartchain` database.

---

### Step 2: Start the Web Application
Double-click:
```cmd
start-app.bat
```
*(Or run in VS Code Terminal:)*
```powershell
.\mvnw.cmd spring-boot:run
```

---

### Step 3: Open in Browser
Open your browser and navigate to:
- **Home Page:** [http://localhost:8080](http://localhost:8080)
- **Vendor Portal:** [http://localhost:8080/vendor.html](http://localhost:8080/vendor.html)
- **Customer Search:** [http://localhost:8080/search.html](http://localhost:8080/search.html)

---

## 📁 Project Structure

```
JAVA PROJECT/
├── pom.xml                                   # Maven dependencies (Spring Boot, JPA, MySQL)
├── mvnw & mvnw.cmd                          # Maven wrapper
├── start-mysql.bat                           # 1-Click MySQL server starter
├── start-app.bat                             # 1-Click Spring Boot application starter
├── PROJECT_GUIDE.md                          # Full presentation script & viva Q&A
├── mysql-db/                                 # MySQL database storage folder
└── src/
    ├── main/
    │   ├── java/com/smartchain/
    │   │   ├── SmartChainApplication.java    # Spring Boot Main Class
    │   │   ├── model/
    │   │   │   └── Vendor.java               # JPA Entity for MySQL 'vendor' table
    │   │   ├── repository/
    │   │   │   └── VendorRepository.java     # Spring Data JPA Repository
    │   │   ├── service/
    │   │   │   └── VendorService.java        # Core 3-Condition Matching Algorithm
    │   │   ├── dto/
    │   │   │   └── SearchRequest.java        # Customer Search Criteria DTO
    │   │   └── controller/
    │   │       ├── VendorController.java     # REST API for Vendor Registration & Listing
    │   │       ├── SearchController.java     # REST API for Customer Search
    │   │       └── PageController.java       # Clean View Page Routing
    │   └── resources/
    │       ├── application.properties        # MySQL connection & server config
    │       ├── schema.sql                    # SQL Table creation script
    │       └── static/
    │           ├── css/
    │           │   └── style.css             # Premium modern styling
    │           ├── js/
    │           │   ├── vendor.js             # Vendor form submission & live table
    │           │   └── search.js             # Customer search & dynamic matching cards
    │           ├── index.html                # Home Landing Page
    │           ├── vendor.html               # Vendor Registration Page
    │           └── search.html               # Customer Search & Results Page
    └── test/
        └── java/com/smartchain/
            └── VendorServiceTest.java        # Unit tests verifying all 6 prompt test cases
```

---

## 🧪 Testing the 3-Condition Matching Engine

### The 3 Core Rules:
1. **Product Match:** Case-insensitive check (e.g. `rice` matches `Rice`).
2. **Quantity Match:** Vendor available quantity $\ge$ customer required quantity.
3. **Address Match:** Customer's area keyword occurs anywhere inside vendor's shop address.

### 1-Click Review Testing:
1. Navigate to **Customer Search** (`http://localhost:8080/search.html`).
2. Under **Quick Test Cases (1-Click Demo)**, click any button:
   - **Test 1:** Rice, 20 kg @ Kundrathur $\rightarrow$ **MATCH** (Kumar Stores & Sri Traders)
   - **Test 2:** Rice, 200 kg @ Kundrathur $\rightarrow$ **NO MATCH** (Insufficient stock)
   - **Test 3:** Sugar, 20 kg @ Kundrathur $\rightarrow$ **NO MATCH** (Product mismatch)
   - **Test 4:** Rice, 20 kg @ Guindy $\rightarrow$ **NO MATCH** (Area mismatch)
   - **Test 5:** `rice` @ `kundrathur` $\rightarrow$ **MATCH** (Case-insensitivity test)
   - **Test 6:** Substring Area Keyword $\rightarrow$ **MATCH** (Keyword inside full address)

---

## 🎓 College Review & Viva Documentation
Detailed presentation guide, architecture diagrams, 5-minute spoken script, and top 20 viva questions are located in:
👉 [`PROJECT_GUIDE.md`](PROJECT_GUIDE.md)
