# SMART CHAIN: Producer/Vendor and Customer Connectivity System
## Comprehensive College Project Report & Presentation Guide
*Specially prepared for 2nd-Year Computer Science Engineering Students*

---

## 1. Project Abstract
**SMART CHAIN** is a full-stack web application engineered to bridge the communication gap between local grocery/provisions vendors and nearby customers. In conventional shopping workflows, customers frequently visit local stores in person or place phone calls only to discover that the needed product is out of stock or unavailable in the desired quantity. SMART CHAIN resolves this inefficiency through an intelligent, location-aware 3-condition matching engine. Vendors register their shop profile, contact numbers, address, and live inventory. Customers provide only three basic criteria: **Product Name**, **Required Quantity**, and an **Area/Address Keyword**. The backend dynamically queries the MySQL database and filters vendors satisfying: (1) case-insensitive product matching, (2) quantity threshold verification ($\text{Vendor Stock} \ge \text{Customer Need}$), and (3) case-insensitive substring address matching. The system provides immediate, transparent connectivity without forcing customers to provide full postal addresses or navigate complex map interfaces.

---

## 2. Problem Statement
In local retail commerce:
- **Uncertain Inventory:** Consumers spend considerable time traveling between local shops to locate specific staples (e.g., rice, grains, flour) only to face stockouts.
- **Quantity Deficits:** Even when a vendor stocks a product, they might not have the bulk or exact volume the consumer requires.
- **Overly Complex Solutions:** Existing e-commerce applications require elaborate delivery addresses, GPS permissions, card payments, and long waiting times, making them unsuited for instant local pickup and neighborhood connectivity.

---

## 3. Existing System vs. Proposed System

| Feature / Aspect | Existing System | Proposed SMART CHAIN System |
| :--- | :--- | :--- |
| **Vendor Discovery** | Physical store visits or individual phone calls. | Instant centralized web query. |
| **Quantity Verification** | Discovered only after reaching the store. | Verified upfront ($\text{Stock} \ge \text{Requirement}$). |
| **Address Input** | Requires complete door number, street, pincode, GPS. | Requires only an area keyword (e.g., *"Kundrathur"*). |
| **Platform Overhead** | Heavy apps, compulsory sign-ins, delivery commissions. | Lightweight, direct vendor-to-customer connection. |
| **Matching Reliability** | Unstructured, manual searching. | Algorithmic 3-condition backend filter. |

---

## 4. Objectives of the Project
1. **Direct Connectivity:** Establish a clean, accessible channel between neighborhood vendors and local buyers.
2. **Prevent Stockouts:** Ensure customers are directed solely to stores holding sufficient stock.
3. **Keyword-Based Discovery:** Allow flexible, non-restrictive location matching via substring keyword comparison.
4. **Beginner-Friendly Architecture:** Maintain an understandable Model-View-Controller (MVC) codebase that demonstrates fundamental principles of Java, Spring Boot, Spring Data JPA, and MySQL.

---

## 5. System Modules

### Module 1: Vendor Management Portal (`/vendor.html`)
- Allows local store owners to register their shop name, contact number, full physical address, product name, and available stock units.
- Validates that non-empty text and quantities greater than zero are supplied.
- Features a live inventory display reading directly from the MySQL `vendor` table.
- Includes a 1-click **"Load Demo Vendors"** tool for college evaluation.

### Module 2: Customer Search Interface (`/search.html`)
- Displays an uncluttered interface containing **ONLY 3 inputs**:
  1. Product Name
  2. Required Quantity
  3. Address / Area Keyword
- Contains 1-click demonstration chips for evaluating Test Cases 1 through 6.

### Module 3: Core Matching Engine (`VendorService.java`)
- Executes the core business logic evaluating all three conditions simultaneously.
- Returns all qualifying vendors; otherwise delivers the standard *"No matching vendors found."* feedback.

### Module 4: RESTful API Layer (`VendorController.java` & `SearchController.java`)
- Decouples the frontend presentation layer from backend business logic and database access.

---

## 6. Technology Stack

- **Backend Language:** Java (Java 21 LTS)
- **Framework:** Spring Boot 3.3.4
- **Database Connectivity:** **Direct JDBC (Java Database Connectivity)** via `DBConnection.java` and `VendorDAO.java`
- **Database:** MySQL Server 8.0 (Port: 3307)
- **Build Tool:** Apache Maven (configured with Maven Wrapper `mvnw`)
- **Frontend:** Semantic HTML5, Modern CSS3 (Glassmorphism & Flex/Grid design), Vanilla JavaScript (ES6+ `fetch` API)
- **Architecture:** Model-View-Controller (MVC) + Data Access Object (DAO) Pattern

---

## 7. Direct JDBC (Java Database Connectivity) Implementation

SMART CHAIN incorporates direct JDBC implementation for database interaction, following standard 2nd-year CSE Java curriculum requirements:

### The 5 Standard JDBC Steps:
1. **Load Driver:** `Class.forName("com.mysql.cj.jdbc.Driver");`
2. **Open Connection:** `Connection conn = DriverManager.getConnection(url, user, pass);`
3. **Prepare Statement:** `PreparedStatement pstmt = conn.prepareStatement(sql);`
4. **Execute SQL:**
   - For INSERT/UPDATE: `int rows = pstmt.executeUpdate();`
   - For SELECT: `ResultSet rs = pstmt.executeQuery();`
5. **Process ResultSet:** `while(rs.next()) { ... }`
6. **Automatic Close:** Using Java `try-with-resources` to prevent memory/connection leaks.

### Key JDBC Classes in SMART CHAIN:
- [`DBConnection.java`](file:///c:/Users/janan/OneDrive/Desktop/JAVA%20PROJECT/src/main/java/com/smartchain/util/DBConnection.java): Centralizes JDBC driver registration and connection management.
- [`VendorDAO.java`](file:///c:/Users/janan/OneDrive/Desktop/JAVA%20PROJECT/src/main/java/com/smartchain/dao/VendorDAO.java): Implements `saveVendor()`, `getAllVendors()`, and `countVendors()` using `PreparedStatement` and `ResultSet`.
- [`JdbcStatusController.java`](file:///c:/Users/janan/OneDrive/Desktop/JAVA%20PROJECT/src/main/java/com/smartchain/controller/JdbcStatusController.java): Exposes `GET /api/jdbc/status` to demonstrate live JDBC connection metadata to faculty.

---

## 7. System Architecture & Flowchart

```mermaid
flowchart TD
    subgraph Client [Frontend Browser]
        Home["Home Page (index.html)"]
        VendorUI["Vendor Portal (vendor.html)"]
        SearchUI["Customer Search (search.html)"]
    end

    subgraph Backend [Spring Boot Application :8080]
        VC["VendorController (/api/vendors)"]
        SC["SearchController (/api/search)"]
        VS["VendorService (Business Logic)"]
        
        subgraph Algorithm [3-Condition Matching Engine]
            C1{"Condition 1: Product Match?"}
            C2{"Condition 2: Stock >= Required?"}
            C3{"Condition 3: Area in Address?"}
        end
        
        VR["VendorRepository (Spring Data JPA)"]
    end

    subgraph Database [MySQL Server 8.0]
        DB[("Database: smartchain<br/>Table: vendor")]
    end

    Home -->|Click Vendor| VendorUI
    Home -->|Click Customer| SearchUI

    VendorUI -->|POST /api/vendors| VC
    VC --> VS
    VS --> VR
    VR -->|INSERT INTO vendor| DB

    SearchUI -->|POST /api/search| SC
    SC --> VS
    VS --> VR
    VR -->|SELECT * FROM vendor| DB
    DB --> VR
    VR --> VS
    VS --> C1
    C1 -->|Yes| C2
    C1 -->|No| Reject[Do Not Include]
    C2 -->|Yes| C3
    C2 -->|No| Reject
    C3 -->|Yes| Match[Add to Matched Vendors]
    C3 -->|No| Reject
    Match --> SC
    SC -->|JSON Matched Vendors| SearchUI
```

---

## 8. Database Explanation

### Database: `smartchain`
### Table: `vendor`

```sql
CREATE TABLE vendor (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    vendor_name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50) NOT NULL,
    shop_address VARCHAR(500) NOT NULL,
    product VARCHAR(255) NOT NULL,
    available_quantity INT NOT NULL
);
```

### Attribute Descriptions:
1. **`id`**: Unique primary key identifier generated automatically (`AUTO_INCREMENT`).
2. **`vendor_name`**: Name of the vendor or retail shop (e.g., *"Kumar Stores"*).
3. **`phone_number`**: Contact number for customer communication (e.g., *"9876543210"*).
4. **`shop_address`**: Full physical address of the store (e.g., *"12, Gandhi Road, Kundrathur, Chennai"*).
5. **`product`**: Product currently offered by the store (e.g., *"Rice"*).
6. **`available_quantity`**: Current stock count in units or kilograms (e.g., `50`).

---

## 9. Matching Algorithm Explanation

The heart of SMART CHAIN is implemented in [`VendorService.java`](file:///c:/Users/janan/OneDrive/Desktop/JAVA%20PROJECT/src/main/java/com/smartchain/service/VendorService.java).

```java
// Normalize customer inputs
String customerProduct = request.getProduct().trim();
int customerQuantity = request.getQuantity();
String customerArea = request.getArea().trim().toLowerCase();

// Loop through each vendor from database
for (Vendor vendor : allVendors) {
    // Condition 1: Case-insensitive product match
    boolean productMatch = vendor.getProduct().trim().equalsIgnoreCase(customerProduct);

    // Condition 2: Sufficient quantity (Vendor Stock >= Customer Need)
    boolean quantityMatch = vendor.getAvailableQuantity() >= customerQuantity;

    // Condition 3: Substring keyword address match
    boolean addressMatch = vendor.getShopAddress().toLowerCase().contains(customerArea);

    // ALL THREE conditions must be true
    if (productMatch && quantityMatch && addressMatch) {
        matchedVendors.add(vendor);
    }
}
```

### Why Substring Matching?
If the vendor's address is `"12, Gandhi Road, Kundrathur, Chennai"` and the customer inputs `"Kundrathur"`, the Java method `contains()` searches for `"kundrathur"` inside the lowercase address string. Because it exists, `contains()` returns `true`.

---

## 10. Verification of Prompt Test Cases

| Test Case | Customer Query | Target Vendor Data | Result | Explanation |
| :---: | :--- | :--- | :---: | :--- |
| **TC 1** | Rice, 20 kg, *Kundrathur* | Kumar Stores (Rice, 50 kg, *Kundrathur*) | **MATCH** | Rice=Rice, $50 \ge 20$, Kundrathur in Address. |
| **TC 2** | Rice, 20 kg, *Kundrathur* | Ravi Traders (Rice, 15 kg, *Kundrathur*) | **NO MATCH** | $15 < 20$ (Quantity insufficient). |
| **TC 3** | Rice, 20 kg, *Kundrathur* | ABC Store (Wheat, 100 kg, *Kundrathur*) | **NO MATCH** | Wheat $\ne$ Rice (Product mismatch). |
| **TC 4** | Rice, 20 kg, *Kundrathur* | Sri Shop (Rice, 100 kg, *Porur*) | **NO MATCH** | Kundrathur not in Porur address. |
| **TC 5** | `rice`, 20 kg, `kundrathur` | Kumar Stores (Rice, 20 kg, Kundrathur) | **MATCH** | Case-insensitive comparison succeeds. |
| **TC 6** | Rice, 20 kg, *Kundrathur* | Kumar Stores (12, Gandhi Road, Kundrathur...) | **MATCH** | Keyword substring search succeeds. |
| **Multiple** | Rice, 20 kg, *Kundrathur* | Kumar Stores (50 kg) & Sri Traders (100 kg) | **BOTH MATCH** | System returns all qualifying vendors. |

---

## 11. Advantages of SMART CHAIN
1. **Zero Guesswork:** Customers know with 100% certainty that a store has sufficient product quantity before stepping out.
2. **Minimal Input Requirement:** Customers only provide a 1-word or 2-word area keyword, not their private home address.
3. **Lightweight & Fast:** Direct REST API queries executed in milliseconds without third-party mapping latencies.
4. **Clean Code Structure:** Clear separation of concerns (Model, Repository, Service, Controller, View) making it ideal for academic evaluation.

---

## 12. Limitations
1. Does not compute real-time driving distances or turn-by-turn road routes.
2. Vendors currently manage one primary product per registration entry in this base version.
3. Does not process online payments or doorstep deliveries (designed for local discovery).

---

## 13. Future Enhancements
1. **Multi-Product Catalog:** Allow vendors to register an inventory list of multiple items under a single shop profile.
2. **GPS & Radius Search:** Integrate HTML5 Geolocation API and Google Maps to search within a radius (e.g., 2 km or 5 km).
3. **Vendor Authentication:** Provide secure login credentials for vendors to update their prices and stock in real time.
4. **Order Reservation:** Allow customers to reserve their required quantity for 1 hour for store pickup.
5. **Customer Reviews & Ratings:** Enable customer ratings for store service quality.
6. **Mobile App:** Build an Android/iOS Flutter or React Native mobile interface.

---

## 14. Five-Minute Spoken Presentation Script

> *"Good morning respected faculty members and examiners.*
>
> *Today, I am presenting my 2nd-year CSE full-stack project titled **'SMART CHAIN: Producer/Vendor and Customer Connectivity System'**.*
>
> *The core problem SMART CHAIN solves is local retail inefficiency. In everyday life, customers often travel between neighborhood grocery shops only to find that the product they need is out of stock, or the shopkeeper doesn't have the required quantity. Current e-commerce apps are often too heavy, requiring complete home addresses, delivery fees, and long waits.*
>
> *SMART CHAIN offers a lightweight, direct solution:*
> - *Vendors register their shop name, phone number, full address, product, and stock quantity.*
> - *Customers provide only three simple inputs: the product name, how much quantity they need, and an area keyword, such as 'Kundrathur'.*
>
> *Our backend runs a **Three-Condition Matching Algorithm** implemented in Java Spring Boot:*
> 1. *First, it performs a case-insensitive match on the product name.*
> 2. *Second, it confirms that the vendor's available stock is greater than or equal to what the customer requested.*
> 3. *Third, it performs a case-insensitive substring search to check if the customer's area keyword exists anywhere inside the vendor's shop address.*
>
> *If all three conditions are satisfied, the vendor is returned. If multiple vendors match, all of them are displayed. If none match, it cleanly informs the customer.*
>
> *For our technology stack:*
> - *The backend is built with **Java 21**, **Spring Boot 3**, and **Spring Data JPA**.*
> - *The database is **MySQL 8.0**, storing our persistent vendor inventory.*
> - *The frontend is crafted using clean, modern **HTML5, CSS3, and JavaScript** communicating via REST APIs.*
>
> *I have validated the application against all test cases, including case insensitivity, insufficient stock checks, address mismatches, and multiple vendor matching.*
>
> *I am now excited to demonstrate the live application. Thank you."*

---

## 15. Faculty Viva Questions & Model Answers

### Q1: What is the architecture of your application?
**Answer:** The project follows the standard **Model-View-Controller (MVC)** and layered architecture. 
- The **Model layer** (`Vendor.java`) maps to the MySQL database table.
- The **Repository layer** (`VendorRepository.java`) uses Spring Data JPA for database queries.
- The **Service layer** (`VendorService.java`) contains the core 3-condition matching algorithm.
- The **Controller layer** (`VendorController.java`, `SearchController.java`) exposes REST endpoints.
- The **View layer** consists of modern HTML, CSS, and JavaScript.

### Q2: How does the address keyword matching work in Java?
**Answer:** In `VendorService.java`, we normalize both the vendor's address and the customer's area keyword using `.toLowerCase().trim()`. We then use Java's `String.contains()` method:
`vendorAddress.toLowerCase().contains(customerArea.toLowerCase())`.
This returns `true` if the customer's keyword appears anywhere within the vendor's full address.

### Q3: Why did you use `availableQuantity >= requiredQuantity` instead of `==`?
**Answer:** Because a customer needs *at least* that amount. A vendor having 50 kg of rice can easily satisfy a customer who only needs 20 kg. Using `==` would incorrectly reject stores that have plenty of stock.

### Q4: How does Spring Boot connect to MySQL?
**Answer:** We configure the connection in `application.properties` using the MySQL JDBC Driver (`com.mysql.cj.jdbc.Driver`) and the URL `jdbc:mysql://localhost:3307/smartchain`. Spring Boot's HikariCP connection pool manages the active database connections, and Spring Data JPA / Hibernate translates Java objects into SQL queries automatically.

### Q5: What is the role of `SearchRequest.java`?
**Answer:** It is a Data Transfer Object (DTO). It encapsulates the customer's 3 search criteria (`product`, `quantity`, `area`) sent from the frontend JSON payload into a structured Java object for the controller and service.

### Q6: What happens if two or more vendors have the same product and quantity in the same area?
**Answer:** Our algorithm collects every vendor that satisfies all 3 conditions into an `ArrayList<Vendor>`. The backend returns the complete list, and the frontend dynamically displays all matching vendors as separate cards.

### Q7: Explain the JDBC implementation in your project.
**Answer:** We implemented direct JDBC using:
1. `DBConnection.java`: Registers `com.mysql.cj.jdbc.Driver` and creates connections via `DriverManager.getConnection()`.
2. `VendorDAO.java`: Contains database operations using `PreparedStatement` to prevent SQL injection and `ResultSet` to map database rows to `Vendor` objects.
3. We manage resources using `try-with-resources` which guarantees that connections and statements are automatically closed.

### Q8: What is the difference between `Statement` and `PreparedStatement` in JDBC?
**Answer:**
- `Statement` compiles the SQL query every time it is executed and is vulnerable to SQL injection attacks.
- `PreparedStatement` is pre-compiled by the database engine, executes faster on repeated queries, and uses parameterized placeholders (`?`) to prevent SQL injection. In SMART CHAIN, we use `PreparedStatement`.

### Q9: What is `ResultSet` and how do you navigate it?
**Answer:** `ResultSet` is a table of data returned by executing a `SELECT` query via `pstmt.executeQuery()`. Its cursor initially points before the first row. We use `rs.next()` inside a `while` loop to move the cursor forward row-by-row and extract column values using `rs.getString()`, `rs.getInt()`, and `rs.getLong()`.
