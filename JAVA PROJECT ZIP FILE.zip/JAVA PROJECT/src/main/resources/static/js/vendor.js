// Vendor Portal JavaScript

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('vendor-form');
    const notificationArea = document.getElementById('notification-area');
    const vendorsTbody = document.getElementById('vendors-tbody');
    const btnRefresh = document.getElementById('btn-refresh-vendors');
    const btnLoadDemo = document.getElementById('btn-load-demo');

    // Load vendors on initial page load
    loadVendors();

    // Event: Form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Extract and trim inputs
        const vendorData = {
            vendorName: document.getElementById('vendorName').value.trim(),
            phoneNumber: document.getElementById('phoneNumber').value.trim(),
            shopAddress: document.getElementById('shopAddress').value.trim(),
            product: document.getElementById('product').value.trim(),
            availableQuantity: parseInt(document.getElementById('availableQuantity').value, 10)
        };

        // Client-side validations
        if (!vendorData.vendorName || !vendorData.phoneNumber || !vendorData.shopAddress || !vendorData.product) {
            showNotification('Please fill in all required fields.', 'error');
            return;
        }

        if (isNaN(vendorData.availableQuantity) || vendorData.availableQuantity <= 0) {
            showNotification('Available quantity must be greater than 0.', 'error');
            return;
        }

        try {
            const response = await fetch('/api/vendors', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(vendorData)
            });

            const data = await response.json();

            if (response.ok) {
                // Exact message requested by the prompt
                showNotification('Vendor details added successfully.', 'success');
                form.reset();
                loadVendors();
            } else {
                showNotification(data.message || 'Failed to add vendor.', 'error');
            }
        } catch (error) {
            console.error('Error adding vendor:', error);
            showNotification('Server communication error. Make sure the Spring Boot backend is running.', 'error');
        }
    });

    // Event: Refresh button
    if (btnRefresh) {
        btnRefresh.addEventListener('click', loadVendors);
    }

    // Event: Load demo vendors
    if (btnLoadDemo) {
        btnLoadDemo.addEventListener('click', async () => {
            try {
                const response = await fetch('/api/vendors/sample-data', {
                    method: 'POST'
                });
                const data = await response.json();
                if (response.ok) {
                    showNotification('Demo vendors loaded successfully into database.', 'success');
                    loadVendors();
                } else {
                    showNotification('Could not load demo vendors.', 'error');
                }
            } catch (err) {
                console.error(err);
                showNotification('Could not connect to backend server.', 'error');
            }
        });
    }

    // Fetch and display vendors in table
    async function loadVendors() {
        try {
            const response = await fetch('/api/vendors');
            if (!response.ok) throw new Error('Network error');
            const vendors = await response.json();

            if (!vendors || vendors.length === 0) {
                vendorsTbody.innerHTML = `
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">
                            No vendors registered in database yet. Add one above or click "Load Demo Vendors".
                        </td>
                    </tr>
                `;
                return;
            }

            vendorsTbody.innerHTML = vendors.map(v => `
                <tr>
                    <td><span style="font-family: 'JetBrains Mono', monospace; font-size: 0.8rem; color: #94a3b8;">#${v.id}</span></td>
                    <td><strong>${escapeHtml(v.vendorName)}</strong></td>
                    <td><a href="tel:${escapeHtml(v.phoneNumber)}" style="color: #38bdf8; text-decoration: underline;" title="Call ${escapeHtml(v.vendorName)}">${escapeHtml(v.phoneNumber)}</a></td>
                    <td style="max-width: 250px;">${escapeHtml(v.shopAddress)}</td>
                    <td><span class="v-badge-pill badge-product">${escapeHtml(v.product)}</span></td>
                    <td><span class="v-badge-pill badge-qty">${v.availableQuantity} units</span></td>
                </tr>
            `).join('');

        } catch (error) {
            console.error('Error fetching vendors:', error);
            vendorsTbody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; color: #f87171; padding: 1.5rem;">
                        Could not load vendors from database. Please check backend connection.
                    </td>
                </tr>
            `;
        }
    }

    // Helper to display notifications
    function showNotification(message, type = 'info') {
        const alertClass = type === 'success' ? 'alert-success' : (type === 'error' ? 'alert-error' : 'alert-info');
        const icon = type === 'success' ? '✅' : (type === 'error' ? '⚠️' : 'ℹ️');

        notificationArea.innerHTML = `
            <div class="alert ${alertClass}">
                <span>${icon}</span>
                <span>${escapeHtml(message)}</span>
            </div>
        `;

        // Scroll into view
        notificationArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

        // Auto remove success after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                if (notificationArea.firstElementChild) {
                    notificationArea.innerHTML = '';
                }
            }, 6000);
        }
    }

    // XSS sanitizer helper
    function escapeHtml(str) {
        if (!str) return '';
        return str
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
});
