package com.smartchain.model;

import jakarta.persistence.*;

/**
 * Entity representing a Vendor (Producer/Shop) in the Smart Chain system.
 * Mapped to the 'vendor' table in MySQL.
 */
@Entity
@Table(name = "vendor")
public class Vendor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "vendor_name", nullable = false)
    private String vendorName;

    @Column(name = "phone_number", nullable = false)
    private String phoneNumber;

    @Column(name = "shop_address", nullable = false, length = 500)
    private String shopAddress;

    @Column(name = "product", nullable = false)
    private String product;

    @Column(name = "available_quantity", nullable = false)
    private Integer availableQuantity;

    // Default constructor (required by JPA)
    public Vendor() {
    }

    // Parameterized constructor for easy object creation
    public Vendor(String vendorName, String phoneNumber, String shopAddress, String product, Integer availableQuantity) {
        this.vendorName = vendorName;
        this.phoneNumber = phoneNumber;
        this.shopAddress = shopAddress;
        this.product = product;
        this.availableQuantity = availableQuantity;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Integer getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(Integer availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    @Override
    public String toString() {
        return "Vendor{" +
                "id=" + id +
                ", vendorName='" + vendorName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", shopAddress='" + shopAddress + '\'' +
                ", product='" + product + '\'' +
                ", availableQuantity=" + availableQuantity +
                '}';
    }
}
