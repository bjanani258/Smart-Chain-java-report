@echo off
title SMART CHAIN - Spring Boot Web Application
echo ===================================================
echo   Starting SMART CHAIN Spring Boot Web Application
echo ===================================================
call mvnw.cmd spring-boot:run
pause
